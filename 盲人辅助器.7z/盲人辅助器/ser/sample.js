var AipSpeechClient = require("baidu-aip-sdk").speech;
var fs = require('fs');
// 设置APPID/AK/SK
var APP_ID = "14835228";
var API_KEY = "WDZmbIsSUGjdvLqnopnmaABs";
var SECRET_KEY = "2TvKUnBaGTTE56oywKWmwLiyr7MooGUd";

// 新建一个对象，建议只保存一个对象调用服务接口
var client = new AipSpeechClient(APP_ID, API_KEY, SECRET_KEY);

const express = require('express');

var http=require('http');

//导入url模块
var url=require('url');
var querystring = require("querystring");

http.createServer(function(request,response){
    request.setEncoding('utf-8');

     var postData = "";
    // 数据块接收中
    request.on("data", function (postDataChunk) {
        postData += postDataChunk;
    });

    request.on("end", function () {
        console.log('数据接收完毕');
        var params = querystring.parse(postData);//GET & POST  ////解释表单数据部分{name="zzl",email="zzl@sina.com"}
        console.log(params["words"]);
	client.text2audio(params["words"]).then(function(result) {
    if (result.data) {
        fs.writeFileSync('1.mp3', result.data);
		response.end("ok");
    } else {
        // 服务发生错误
        console.log(result)
    }
}, function(e) {
    // 发生网络错误
    console.log(e)
});
    });


}).listen(9000);
console.log("--HTTP NodeJS Connect--");


var http = require('http')
var fs = require('fs')
var url = require('url')
var path = require('path')
var server = http.createServer(function(request, response){
    //获取输入的url解析后的对象
    var pathObj = url.parse(request.url, true);
    //static文件夹的绝对路径
    var staticPath = path.resolve(__dirname, '')
    //获取资源文件绝对路径
    var filePath = path.join(staticPath, pathObj.pathname)
    //异步读取file
    fs.readFile(filePath, 'binary', function(err, fileContent){
        if(err){
            console.log('404')
            response.writeHead(404, 'not found')
            response.end('<h1>404 Not Found</h1>')
        }else{
            console.log('ok')
            response.write(fileContent, 'binary')
            response.end()
        }
    })
})
server.listen(8080)
console.log('visit http://localhost:8080')


